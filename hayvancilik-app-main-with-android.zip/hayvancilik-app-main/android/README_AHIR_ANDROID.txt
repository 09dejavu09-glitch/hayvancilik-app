AHIR Android platform folder

This android/ folder was added to the working AHIR project backup.
It is intended to be used with Flutter. The local.properties file is intentionally not included;
Flutter/Android Studio creates it with the local Flutter and Android SDK paths.

The release build uses the debug signing key for development/testing, matching the existing
Codemagic setup. A production Play Store release should use a dedicated signing key.

The Gradle wrapper JAR is intentionally not bundled here because this environment does not
have the Flutter SDK/Gradle wrapper cache. Running `flutter create --platforms=android .`
can regenerate the exact wrapper files for the installed Flutter SDK without changing lib/main.dart.
